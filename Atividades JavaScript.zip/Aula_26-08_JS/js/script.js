
/*
function alterarCont() {

    document.getElementById("exemplo").innerHTML = "Alterou conteúdo";

}

var nome = "João";
var idade = 20;
var curso = "Desenvolvimento de Sistemas";


document.writeln(nome + " tem " + idade + " anos de idade. É aluno do curso: " + curso)


var para = document.querySelector('p');

para.addEventListener('click', atualizarNome);

function atualizarNome() {
    var nome = prompt('Insira um novo nome')
    para.textContent = 'Aluno: ' + nome;
}

let num1 = parseInt(prompt("Informe um valor: "))
let num2 = parseInt(prompt("Informe outro valor: "))
alert(num1 + num2);
console.log(num1 + num2);

let idade = parseInt(prompt("Qual a sua idade?"))

if(idade >= 18){
    alert("Você é maior de idade.")
} else{
    alert("Você é menor de idade.")
}

*/
alert("Atividade 1 - Compração de números")

let num1 = parseInt(prompt("Informe um valor"));

let num2 = parseInt(prompt("Informe outro valor"));

if(num1 == num2){
    alert(num1 + " são iguais " + num2)
} else if(num1 > num2){
    alert(num1 + " é maior que " + num2)
} else{
    alert(num2 + " é maior que " + num1)
}

alert("Atividade 2 - Descubra se pode votar")

let idade = parseInt(prompt("Informe a sua idade"));


if(idade < 16){
    alert("Você não pode votar")
} else if((idade >= 16 && idade < 18) || (idade >= 60)){
    alert("Você pode votar")
} else if(idade > 18 || idade < 60){
    alert("Você deve votar")
}

alert("Atividade 3 - Média")

let nota1 = parseInt(prompt("Informe a primeira nota"));

let nota2 = parseInt(prompt("Informe a segunda nota"));

if ((nota1 + nota2) / 2 >= 6) {
    alert("Média: " + (nota1 + nota2) / 2 + " - Está aprovado")
} else {
    alert("Média: " + (nota1 + nota2) / 2 + " - Está reprovado")
}
