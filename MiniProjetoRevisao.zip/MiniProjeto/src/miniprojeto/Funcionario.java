package miniprojeto;

import java.util.ArrayList;
import java.util.Scanner;

public class Funcionario extends Pessoa {

    static Scanner sc = new Scanner(System.in);
    static ArrayList<Funcionario> listaDeFuncionarios = new ArrayList<>();

    private String cargo;

    public Funcionario() {
    }

    /**
     *
     * @param cargo
     * @param nome
     * @param cpf
     */
    public Funcionario(String cargo, String nome, Long cpf) {
        super(nome, cpf);
        this.cargo = cargo;
    }

    /**
     * Imprime os dados do Funcionario
     */
    /**
     * @return the cargo
     */
    public String getCargo() {
        return cargo;
    }

    /**
     * @param cargo the cargo to set
     */
    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    /*
    Exibe uma lista de opera��es
     */
    public static void menuFuncionario() {

        int opcao = -1;

        do {
            try {

                System.out.println("--Funcionario--");
                System.out.println("1 - Cadastar");
                System.out.println("2 - Listar");
                System.out.println("3 - Exluir");
                System.out.println("4 - Atualizar");
                System.out.println("0 - Sair");
                opcao = sc.nextInt();
                sc.nextLine();

                switch (opcao) {
                    case 1:
                        Funcionario.cadastarFuncionario();
                        break;

                    case 2:
                        Funcionario.listarFuncionario();
                        break;
                    case 3:

                        Funcionario.excluirFuncionario();
                        break;

                    case 4:
                        Funcionario.atualizarFuncionario();
                        break;
                    case 0:
                        break;
                    default:
                        throw new AssertionError();
                }
            } catch (Exception e) {
                System.out.println("Erro - Tente Novamente");
                sc.nextLine();
            }

        } while (opcao != 0);

    }

    /*
    Cadastra um funcion�rio
     */
    public static void cadastarFuncionario() {

        System.out.println("Informe o nome: ");
        String nome = sc.nextLine();

        System.out.println("Informe o CPF: ");
        Long cpf = sc.nextLong();
        sc.nextLine();

        System.out.println("Informe o cargo: ");
        String cargo = sc.nextLine();

        Funcionario f = new Funcionario(cargo, nome, cpf);
        listaDeFuncionarios.add(f);

    }

    /*
    Exibe uma lista de funcion�rios cadastrados
     */
    public static void listarFuncionario() {

        System.out.println("***** Lista de Funcionarios *****");
        for (int i = 0; i < listaDeFuncionarios.size(); i++) {

            Funcionario f = listaDeFuncionarios.get(i);

            System.out.println("ID: " + i);
            f.imprimir();
            System.out.println("------");
        }
        System.out.println("*****************************");
    }

    /*
    Exclui um dos funcion�rios
     */
    public static void excluirFuncionario() {

        Funcionario.listarFuncionario();

        System.out.println("Escolha o ID do funcion�rio que deseja excluir:");
        int id = sc.nextInt();

        listaDeFuncionarios.remove(id);

    }

    /*
     Atualiza os dados de um funcion�rio
     */
    public static void atualizarFuncionario() {

        if (listaDeFuncionarios.isEmpty()) {
            System.out.println("Nenhum funcion�rio cadastrado");
        } else {
            Cliente.listarCliente();

            System.out.println("Escolha o ID do funcion�rio que deseja atualizar:");
            int id = sc.nextInt();
            sc.nextLine();

            if (id < listaDeFuncionarios.size() || id > listaDeFuncionarios.size()) {
                System.out.println("ID n�o foi encotrado");
            } else {
                System.out.println("Informe o nome: ");
                String nome = sc.nextLine();

                System.out.println("Informe o CPF: ");
                Long cpf = sc.nextLong();
                sc.nextLine();

                System.out.println("Informe o cargo: ");
                String cargo = sc.nextLine();

                Funcionario f = new Funcionario(cargo, nome, cpf);

                listaDeFuncionarios.set(id, f);
            }

        }

    }

    public void imprimir() {
        System.out.println("Nome: " + this.getNome());
        System.out.println("CPF: " + this.getCpf());
        System.out.println("Cargo: " + this.getCargo());
    }
}
