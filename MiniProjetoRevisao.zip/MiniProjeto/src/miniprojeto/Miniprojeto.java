package miniprojeto;

import java.util.Scanner;

public class Miniprojeto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int opcao = -1;

        do {
            try {
                System.out.println("Escolha um op��o: ");
                System.out.println("1 - Funcion�rio");
                System.out.println("2 - Cliente");
                System.out.println("0 - Sair");
                opcao = sc.nextInt();
                sc.nextLine();

                switch (opcao) {
                    case 1:
                        Funcionario.menuFuncionario();
                        break;

                    case 2:
                        Cliente.menuCliente();
                        break;
                    case 0:
                        break;
                    default:
                        throw new AssertionError();
                }
            } catch (Exception e) {
                System.out.println("Erro - Tente Novamente");
                sc.nextLine();
            }

        } while (opcao != 0);

    }
}
