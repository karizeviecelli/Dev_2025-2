package miniprojeto;

import java.util.ArrayList;
import java.util.Scanner;

public class Cliente extends Pessoa {

    private String email;

    static Scanner sc = new Scanner(System.in);
    static ArrayList<Cliente> listaDeClientes = new ArrayList<>();

    public Cliente() {
    }

    /**
     * Construtor do objeto cliente
     *
     * @param email
     * @param nome
     * @param cpf
     */
    public Cliente(String email, String nome, Long cpf) {
        super(nome, cpf);
        this.email = email;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /*
    Exibe uma lista de opera��es
     */
    public static void menuCliente() {

        int opcao = -1;

        do {
            try {

                System.out.println("--Cliente--");
                System.out.println("1 - Cadastar");
                System.out.println("2 - Listar");
                System.out.println("3 - Excluir");
                System.out.println("4 - Atualizar");
                System.out.println("0 - Sair");
                opcao = sc.nextInt();
                sc.nextLine();

                switch (opcao) {
                    case 1:
                        Cliente.cadastarCliente();
                        break;

                    case 2:
                        Cliente.listarCliente();
                        break;

                    case 3:
                        Cliente.excluirCliente();
                        break;

                    case 4:
                        Cliente.atualizarCliente();
                    case 0:
                        break;
                    default:
                        throw new AssertionError();
                }
            } catch (Exception e) {
                System.out.println("Erro - Tente Novamente");
                sc.nextLine();
            }

        } while (opcao != 0);

    }

    /*
    Cadastra um cliente
     */
    public static void cadastarCliente() {

        System.out.println("Informe o nome: ");
        String nome = sc.nextLine();

        System.out.println("Informe o CPF: ");
        Long cpf = sc.nextLong();
        sc.nextLine();

        System.out.println("Informe o email: ");
        String email = sc.nextLine();

        Cliente c = new Cliente(email, nome, cpf);
        listaDeClientes.add(c);
    }

    /*
    Exibe uma lista de clientes cadastrados
     */
    public static void listarCliente() {

        System.out.println("***** Lista de Clientes *****");
        for (int i = 0; i < listaDeClientes.size(); i++) {

            Cliente c = listaDeClientes.get(i);

            System.out.println("ID: " + i);
            c.imprimir();
            System.out.println("------");
        }
        System.out.println("*****************************");
    }

    /*
    Exclui um cliente da lista
     */
    public static void excluirCliente() {

        Cliente.listarCliente();

        System.out.println("Escolha o ID do cliente que deseja excluir:");
        int id = sc.nextInt();

        listaDeClientes.remove(id);

    }

    /*
    Atualiza os dados de um cliente
     */
    public static void atualizarCliente() {

        if (listaDeClientes.isEmpty()) {
            System.out.println("Nenhum cliente cadastrado");
        } else {
            Cliente.listarCliente();

            System.out.println("Escolha o ID do cliente que deseja atualizar:");
            int id = sc.nextInt();
            sc.nextLine();

            if ((id > listaDeClientes.size()) || (id < listaDeClientes.size())) {
                System.out.println("ID n�o foi encontrado");
            } else {
                System.out.println("Informe o nome: ");
                String nome = sc.nextLine();

                System.out.println("Informe o CPF: ");
                Long cpf = sc.nextLong();
                sc.nextLine();

                System.out.println("Informe o email: ");
                String email = sc.nextLine();

                Cliente c = new Cliente(email, nome, cpf);

                listaDeClientes.set(id, c);
            }

        }

    }

    /**
     * Imprime os dados do Cliente
     */
    public void imprimir() {
        System.out.println("Nome: " + this.getNome());
        System.out.println("CPF: " + this.getCpf());
        System.out.println("Email: " + this.getEmail());
    }

}
