package com.senai.calculadoracontinuacao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculadoracontinuacaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculadoracontinuacaoApplication.class, args);
	}

}
