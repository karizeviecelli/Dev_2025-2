package com.senai.crud.exception;

public class InvalidOperationException extends RuntimeException {


    public InvalidOperationException(String message) {
        super(message);
    }
}