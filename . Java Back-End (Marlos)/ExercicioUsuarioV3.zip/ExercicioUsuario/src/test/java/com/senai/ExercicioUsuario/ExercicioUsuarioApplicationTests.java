package com.senai.ExercicioUsuario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExercicioUsuarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
