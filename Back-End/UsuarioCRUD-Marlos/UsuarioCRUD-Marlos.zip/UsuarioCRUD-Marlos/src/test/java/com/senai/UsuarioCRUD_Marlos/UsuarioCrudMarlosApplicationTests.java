package com.senai.UsuarioCRUD_Marlos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsuarioCrudMarlosApplicationTests {

	@Test
	void contextLoads() {
	}

}
