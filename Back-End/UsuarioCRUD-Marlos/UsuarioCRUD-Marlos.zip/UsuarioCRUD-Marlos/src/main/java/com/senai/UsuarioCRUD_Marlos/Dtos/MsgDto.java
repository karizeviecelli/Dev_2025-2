package com.senai.UsuarioCRUD_Marlos.Dtos;

public class MsgDto {

    private String nome;
    private String msg;

    public MsgDto() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
