package com.senai.UsuarioCRUD_Marlos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsuarioCrudMarlosApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsuarioCrudMarlosApplication.class, args);
	}

}
